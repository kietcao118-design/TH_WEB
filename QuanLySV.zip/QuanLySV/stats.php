<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

include 'config.php';

// Tổng số sinh viên
$total_sql = "SELECT COUNT(*) as total FROM sinhvien";
$total_res = $conn->query($total_sql);
$total = $total_res->fetch_assoc()['total'];

// Điểm trung bình
$avg_sql = "SELECT AVG(diem) as avg_diem FROM sinhvien";
$avg_res = $conn->query($avg_sql);
$avg_diem = round($avg_res->fetch_assoc()['avg_diem'],2);

// Số sinh viên theo lớp
$class_sql = "SELECT lop, COUNT(*) as count FROM sinhvien GROUP BY lop";
$class_res = $conn->query($class_sql);

// Xếp loại
$xeploai_sql = "
SELECT 
    SUM(CASE WHEN diem >= 8 THEN 1 ELSE 0 END) as gioi,
    SUM(CASE WHEN diem >= 6.5 AND diem < 8 THEN 1 ELSE 0 END) as kha,
    SUM(CASE WHEN diem >=5 AND diem <6.5 THEN 1 ELSE 0 END) as trungbinh,
    SUM(CASE WHEN diem <5 THEN 1 ELSE 0 END) as yeu
FROM sinhvien";
$xeploai_res = $conn->query($xeploai_sql);
$xeploai = $xeploai_res->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thống kê sinh viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('asset/anh.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            margin:0; padding:0;
            position:relative;
        }
        body::before {
            content:"";
            position:fixed;
            top:0; left:0;
            width:100%; height:100%;
            background: rgba(255,255,255,0.3);
            z-index:-1;
        }

        .header-vlu {
            background-color: #C8102E;
            color: white;
            padding: 20px;
            text-align: center;
            font-weight: bold;
            font-size: 22px;
            border-radius: 0 0 12px 12px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
        }

        .btn-back {
            display:inline-block;
            margin-bottom:15px;
            padding:8px 15px;
            background-color:#C8102E;
            color:white;
            text-decoration:none;
            border-radius:6px;
            font-weight:bold;
            transition:0.3s;
        }
        .btn-back:hover {
            background-color:#a60b24;
        }

        .card-vlu {
            background: rgba(255,255,255,0.85);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 4px 15px rgba(0,0,0,0.15);
            margin-top: 30px;
        }

        .table-vlu th {
            background-color: #C8102E;
            color: white;
        }

        .table-vlu td {
            background: rgba(255,255,255,0.95);
        }

        .table-vlu tbody tr:hover {
            background-color: rgba(200,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="header-vlu">📊 Thống kê sinh viên</div>

<div class="container card-vlu mt-4">
    <a href="index.php" class="btn-back">← Quay lại</a>

    <h4>Tổng số sinh viên: <?= $total ?></h4>
    <h4>Điểm trung bình: <?= $avg_diem ?></h4>

    <h5>Số sinh viên theo lớp:</h5>
    <table class="table table-bordered table-vlu">
        <thead>
            <tr>
                <th>Lớp</th>
                <th>Số lượng</th>
            </tr>
        </thead>
        <tbody>
            <?php if($class_res->num_rows==0): ?>
                <tr><td colspan="2" style="text-align:center;">Chưa có dữ liệu</td></tr>
            <?php else: ?>
                <?php while($row=$class_res->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['lop'] ?></td>
                        <td><?= $row['count'] ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <h5>Xếp loại sinh viên:</h5>
    <table class="table table-bordered table-vlu">
        <thead>
            <tr>
                <th>Xếp loại</th>
                <th>Số lượng</th>
            </tr>
        </thead>
        <tbody>
            <tr><td>Giỏi (≥8)</td><td><?= $xeploai['gioi'] ?></td></tr>
            <tr><td>Khá (6.5–7.9)</td><td><?= $xeploai['kha'] ?></td></tr>
            <tr><td>Trung bình (5–6.4)</td><td><?= $xeploai['trungbinh'] ?></td></tr>
            <tr><td>Yếu (<5)</td><td><?= $xeploai['yeu'] ?></td></tr>
        </tbody>
    </table>
</div>
</body>
</html>
