<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

include 'config.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý sinh viên - Văn Lang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('asset/anh.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            margin:0; padding:0;
            font-family: Arial, sans-serif;
        }
        body::before {
            content:"";
            position:fixed;
            top:0; left:0;
            width:100%; height:100%;
            background: rgba(255,255,255,0.3);
            z-index:-1;
        }
        .header-vlu {
            background-color: #C8102E;
            color: white;
            padding: 20px;
            text-align: center;
            font-weight: bold;
            font-size: 22px;
            border-radius: 0 0 12px 12px;
        }
        .menu-vlu {
            background-color: white;
            border-bottom: 2px solid #ddd;
            text-align: center;
        }
        .menu-vlu a {
            color: #C8102E;
            text-decoration: none;
            font-weight: bold;
            padding: 12px 20px;
            display: inline-block;
            transition: 0.3s;
        }
        .menu-vlu a:hover {
            background-color: #ffe5e8;
            border-radius: 5px;
        }
        .card-vlu {
            background: rgba(255,255,255,0.85);
            padding: 25px;
            border-radius:12px;
            box-shadow:0 4px 15px rgba(0,0,0,0.15);
            margin-top:30px;
        }
        .btn-vlu-primary {
            background-color: #C8102E;
            color:white;
            border:none;
            border-radius:6px;
            padding:5px 10px;
            transition:0.3s;
        }
        .btn-vlu-primary:hover {
            background-color: #a60b24;
        }
        .btn-danger {
            border-radius:6px;
        }
        .table-vlu th {
            background-color: #C8102E;
            color:white;
        }
        .table-vlu td {
            background: rgba(255,255,255,0.85);
        }
        .table-vlu tbody tr:hover {
            background-color: rgba(200,0,0,0.1);
        }
    </style>
</head>
<body>

<div class="header-vlu">🎓 Trường Đại học Văn Lang - Hệ thống Quản lý Sinh viên</div>

<div class="menu-vlu">
    <a href="index.php">Trang chủ</a>
    <a href="add.php">Thêm sinh viên</a>
    <a href="sort.php">Sắp xếp</a>
    <a href="stats.php">Thống kê</a>
    <a href="logout.php">Đăng xuất</a>
</div>

<div class="container">
    <div class="card-vlu">
        <h3 class="mb-3">Danh sách sinh viên</h3>
        <table class="table table-bordered table-vlu">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã SV</th>
                    <th>Họ tên</th>
                    <th>Lớp</th>
                    <th>Điểm</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM sinhvien ORDER BY id ASC"; // sinh viên mới lên sau
                $result = $conn->query($sql);
                $stt = 1; // STT bắt đầu từ 1

                if($result->num_rows == 0){
                    echo "<tr><td colspan='6' style='text-align:center;'>Chưa có sinh viên nào</td></tr>";
                } else {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$stt}</td>
                            <td>{$row['masv']}</td>
                            <td>{$row['hoten']}</td>
                            <td>{$row['lop']}</td>
                            <td>{$row['diem']}</td>
                            <td>
                                <a href='edit.php?id={$row['id']}' class='btn btn-vlu-primary btn-sm'>Sửa</a>
                                <a href='delete.php?id={$row['id']}' class='btn btn-danger btn-sm'
                                   onclick='return confirm(\"Bạn có chắc chắn muốn xóa?\")'>Xóa</a>
                            </td>
                        </tr>";
                        $stt++; // tăng STT liên tục
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>