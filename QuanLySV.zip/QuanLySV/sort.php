<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

include 'config.php';

// Lấy cột và thứ tự sắp xếp từ URL
$column = isset($_GET['column']) ? $_GET['column'] : 'masv';
$order = isset($_GET['order']) ? $_GET['order'] : 'ASC';

// Chỉ cho phép các cột hợp lệ
$allowed_columns = ['masv','hoten','lop','diem'];
if(!in_array($column, $allowed_columns)) $column = 'masv';

// Chỉ cho phép ASC hoặc DESC
$order = strtoupper($order) == 'ASC' ? 'ASC' : 'DESC';

// Query: luôn ORDER BY id ASC để STT tăng dần theo thứ tự thêm
$sql = "SELECT * FROM sinhvien ORDER BY id ASC";
$result = $conn->query($sql);

// Hàm hiển thị mũi tên sắp xếp
function arrow($col){
    global $column, $order;
    if($column == $col){
        return $order == 'ASC' ? '↑' : '↓';
    }
    return '';
}

// Hàm toggle thứ tự
function toggleOrder($col){
    global $column, $order;
    if($column == $col){
        return $order == 'ASC' ? 'DESC' : 'ASC';
    }
    return 'ASC';
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sắp xếp sinh viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0;
            background-image: url('asset/anh.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
        }
        body::before { content: ""; position: fixed; top:0; left:0;
            width:100%; height:100%; background: rgba(255,255,255,0.3); z-index: -1; }
        .header-vlu { background-color: #C8102E; color: white; padding: 20px;
            text-align: center; font-weight: bold; font-size: 22px; border-radius: 0 0 12px 12px; }
        .card-vlu { background: rgba(255,255,255,0.75); padding: 25px; border-radius: 12px; margin-top: 30px; }
        .table-vlu th { background-color: #C8102E; color: white; }
        .table-vlu td { background: rgba(255,255,255,0.85); }
        .table-vlu tbody tr:hover { background-color: rgba(200,0,0,0.1); }
        th a { text-decoration:none; color:white; font-weight:bold; }
        th a:hover { text-decoration:underline; color:#ffdcdc; }
        .btn-back { display:inline-block; margin-bottom:15px; padding:8px 15px; background-color:#C8102E;
            color:white; text-decoration:none; border-radius:6px; font-weight:bold; transition:0.3s; }
        .btn-back:hover { background-color:#a60b24; }
    </style>
</head>
<body>

<div class="header-vlu">📊 Sắp xếp sinh viên</div>

<div class="container card-vlu mt-4">
    <a href="index.php" class="btn-back">← Quay lại</a>

    <table class="table table-bordered table-vlu mt-3">
        <thead>
            <tr>
                <th>STT</th>
                <th><a href="sort.php?column=masv&order=<?= toggleOrder('masv') ?>">Mã SV <?= arrow('masv') ?></a></th>
                <th><a href="sort.php?column=hoten&order=<?= toggleOrder('hoten') ?>">Họ tên <?= arrow('hoten') ?></a></th>
                <th><a href="sort.php?column=lop&order=<?= toggleOrder('lop') ?>">Lớp <?= arrow('lop') ?></a></th>
                <th><a href="sort.php?column=diem&order=<?= toggleOrder('diem') ?>">Điểm <?= arrow('diem') ?></a></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $stt = 1;
            if($result->num_rows == 0){
                echo "<tr><td colspan='5' style='text-align:center;'>Chưa có dữ liệu</td></tr>";
            } else {
                while($row = $result->fetch_assoc()){
                    echo "<tr>
                        <td>{$stt}</td>
                        <td>{$row['masv']}</td>
                        <td>{$row['hoten']}</td>
                        <td>{$row['lop']}</td>
                        <td>{$row['diem']}</td>
                    </tr>";
                    $stt++;
                }
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
