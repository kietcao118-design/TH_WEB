<?php
session_start();
include 'config.php';

if(isset($_POST['register'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    if($password !== $password_confirm){
        $error = "Mật khẩu không khớp!";
    } else {
        // Kiểm tra username đã tồn tại chưa (prepared statement)
        $stmt_check = $conn->prepare("SELECT * FROM users WHERE username=?");
        $stmt_check->bind_param("s", $username);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if($result_check->num_rows > 0){
            $error = "Tên đăng nhập đã tồn tại!";
        } else {
            // Hash mật khẩu
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            // Thêm user mới
            $stmt_insert = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt_insert->bind_param("ss", $username, $hashed);
            if($stmt_insert->execute()){
                $success = "Tạo tài khoản thành công! <a href='login.php'>Đăng nhập ngay</a>";
            } else {
                $error = "Lỗi: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Đăng ký tài khoản</title>
    <link rel="stylesheet" href="asset/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('asset/anh.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            margin:0; padding:0;
            position:relative;
        }
        body::before {
            content:"";
            position:fixed;
            top:0; left:0;
            width:100%; height:100%;
            background: rgba(255,255,255,0.3);
            z-index:-1;
        }

        .header-vlu {
            background-color: #C8102E;
            color: white;
            padding: 20px;
            text-align: center;
            font-weight: bold;
            font-size: 22px;
            border-radius: 0 0 12px 12px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
        }

        .card-vlu {
            background: rgba(255,255,255,0.7);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 4px 15px rgba(0,0,0,0.15);
            margin: 50px auto;
            width: 350px;
        }

        .form-control {
            width: 100%;
            padding: 8px 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius:6px;
        }

        .btn-vlu-primary {
            width: 100%;
            background-color: #C8102E;
            color:white;
            border:none;
            padding:10px;
            border-radius:6px;
            font-weight:bold;
            cursor:pointer;
            transition:0.3s;
            margin-bottom:10px;
        }

        .btn-vlu-primary:hover {
            background-color: #a60b24;
        }

        .btn-secondary {
            display:block;
            width:100%;
            padding:10px;
            text-align:center;
            background:#ccc;
            border-radius:6px;
            text-decoration:none;
            color:#000;
            transition:0.3s;
        }

        .btn-secondary:hover {
            background:#bbb;
        }

        .error-msg { color:red; text-align:center; margin-bottom:15px; }
        .success-msg { color:green; text-align:center; margin-bottom:15px; }

        p { text-align:center; }
        a { color:#C8102E; font-weight:bold; text-decoration:none; }
        a:hover { text-decoration:underline; }
    </style>
</head>
<body>
<div class="header-vlu">🎓 Đăng ký tài khoản</div>

<div class="container card-vlu">
    <?php 
    if(isset($error)) echo "<p class='error-msg'>$error</p>"; 
    if(isset($success)) echo "<p class='success-msg'>$success</p>"; 
    ?>
    <form method="POST">
        <label>Tên đăng nhập</label>
        <input type="text" name="username" class="form-control" required autofocus>

        <label>Mật khẩu</label>
        <input type="password" name="password" class="form-control" required>

        <label>Nhập lại mật khẩu</label>
        <input type="password" name="password_confirm" class="form-control" required>

        <button type="submit" name="register" class="btn-vlu-primary">Đăng ký</button>
        <a href="login.php" class="btn-secondary">Đăng nhập</a>
    </form>
</div>
</body>
</html>
