<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

include 'config.php';

// Thêm sinh viên
if(isset($_POST['add'])){
    $masv = $_POST['masv'];
    $hoten = $_POST['hoten'];
    $lop = $_POST['lop'];
    $diem = $_POST['diem'];

    $stmt = $conn->prepare("INSERT INTO sinhvien (masv, hoten, lop, diem) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssd", $masv, $hoten, $lop, $diem);

    if($stmt->execute()){
        $stmt->close();
        header("Location: index.php");
        exit;
    } else {
        $error = "Lỗi: Không thể thêm sinh viên!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm sinh viên - Văn Lang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="asset/style.css">
    <style>
        body {
            background-image: url('asset/anh.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            margin:0; padding:0;
        }
        body::before {
            content:"";
            position:fixed;
            top:0; left:0;
            width:100%; height:100%;
            background: rgba(255,255,255,0.3);
            z-index:-1;
        }

        .card-vlu {
            background: rgba(255,255,255,0.75);
            padding: 20px;
            border-radius:12px;
            box-shadow:0 4px 15px rgba(0,0,0,0.15);
            margin-top:30px;
            max-width:500px;
            margin-left:auto;
            margin-right:auto;
        }

        .btn-vlu-primary {
            background-color: #C8102E;
            color:white;
            border:none;
            border-radius:6px;
            padding:8px 15px;
            cursor:pointer;
            font-weight:bold;
            transition:0.3s;
        }
        .btn-vlu-primary:hover { background-color:#a60b24; }

        .btn-secondary {
            display:inline-block;
            padding:8px 15px;
            background:#ccc;
            border-radius:6px;
            text-decoration:none;
            color:#000;
            margin-left:5px;
            transition:0.3s;
        }
        .btn-secondary:hover { background:#bbb; }

        .error-msg { color:red; text-align:center; margin-bottom:15px; }
    </style>
</head>
<body>

<div class="header-vlu">
    🎓 Thêm Sinh viên - Đại học Văn Lang
</div>

<div class="menu-vlu">
    <a href="index.php">Trang chủ</a>
    <a href="add.php">Thêm sinh viên</a>
    <a href="sort.php">Sắp xếp</a>
    <a href="stats.php">Thống kê</a>
    <a href="logout.php">Đăng xuất</a>
</div>

<div class="container">
    <div class="card-vlu mt-4">
        <?php if(isset($error)) echo "<p class='error-msg'>$error</p>"; ?>
        <form method="POST">
            <label>Mã Sinh viên</label>
            <input type="text" name="masv" class="form-control mb-3" required autofocus>

            <label>Họ Tên</label>
            <input type="text" name="hoten" class="form-control mb-3" required>

            <label>Lớp</label>
            <input type="text" name="lop" class="form-control mb-3">

            <label>Điểm</label>
            <input type="number" step="0.1" name="diem" class="form-control mb-3">

            <button type="submit" name="add" class="btn btn-vlu-primary">Lưu</button>
            <a href="index.php" class="btn btn-secondary">Quay lại</a>
        </form>
    </div>
</div>

</body>
</html>
