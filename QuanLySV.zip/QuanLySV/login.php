<?php
session_start();
include 'config.php';

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Chuẩn bị statement để tránh SQL Injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if($row = $result->fetch_assoc()){
        // Kiểm tra mật khẩu đã hash
        if(password_verify($password, $row['password'])){
            $_SESSION['username'] = $username;
            header("Location: index.php");
            exit;
        } else {
            $error = "Sai tên đăng nhập hoặc mật khẩu!";
        }
    } else {
        $error = "Sai tên đăng nhập hoặc mật khẩu!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập hệ thống</title>
    <link rel="stylesheet" href="asset/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('asset/anh.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            margin:0; padding:0;
            position:relative;
        }
        body::before {
            content:"";
            position:fixed;
            top:0; left:0;
            width:100%; height:100%;
            background: rgba(255,255,255,0.3);
            z-index:-1;
        }

        .header-vlu {
            background-color: #C8102E;
            color: white;
            padding: 20px;
            text-align: center;
            font-weight: bold;
            font-size: 22px;
            border-radius: 0 0 12px 12px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
        }

        .card-vlu {
            background: rgba(255,255,255,0.7);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 4px 15px rgba(0,0,0,0.15);
            margin: 50px auto;
            width: 350px;
        }

        .form-control {
            width: 100%;
            padding: 8px 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius:6px;
        }

        .btn-vlu-primary {
            width: 100%;
            background-color: #C8102E;
            color:white;
            border:none;
            padding:10px;
            border-radius:6px;
            font-weight:bold;
            cursor:pointer;
            transition:0.3s;
        }

        .btn-vlu-primary:hover {
            background-color: #a60b24;
        }

        p {
            text-align:center;
        }

        a {
            color:#C8102E;
            text-decoration:none;
            font-weight:bold;
        }
        a:hover {
            text-decoration:underline;
        }

        .error-msg {
            color:red;
            text-align:center;
            margin-bottom:15px;
        }
    </style>
</head>
<body>
<div class="header-vlu">🎓 Đăng nhập hệ thống</div>

<div class="container card-vlu">
    <?php if(isset($error)) echo "<p class='error-msg'>$error</p>"; ?>
    <form method="POST">
        <label>Tên đăng nhập</label>
        <input type="text" name="username" class="form-control" required autofocus>

        <label>Mật khẩu</label>
        <input type="password" name="password" class="form-control" required>

        <button type="submit" name="login" class="btn-vlu-primary">Đăng nhập</button>
    </form>
    <p>Chưa có tài khoản? <a href="register.php">Đăng ký ngay</a></p>
</div>
</body>
</html>
