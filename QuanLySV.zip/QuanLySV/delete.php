<?php
session_start();

// Kiểm tra đăng nhập
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

include 'config.php';

// Kiểm tra ID hợp lệ
if(!isset($_GET['id'])){
    die("Không tìm thấy ID để xóa!");
}

$id = intval($_GET['id']);

// Dùng prepared statement để xóa
$stmt = $conn->prepare("DELETE FROM sinhvien WHERE id = ?");
$stmt->bind_param("i", $id);

if($stmt->execute()){
    $stmt->close();
    header("Location: index.php"); // Quay về danh sách
    exit;
} else {
    echo "Lỗi: " . $conn->error;
}
?>
