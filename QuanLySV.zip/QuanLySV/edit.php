<?php
session_start();

// Kiểm tra đăng nhập
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

include 'config.php';

// Kiểm tra ID hợp lệ
if(!isset($_GET['id'])){
    die("Không có ID!");
}

$id = intval($_GET['id']);

// Lấy dữ liệu sinh viên
$stmt = $conn->prepare("SELECT * FROM sinhvien WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if(!$row){
    die("Sinh viên không tồn tại!");
}

// Xử lý cập nhật
if(isset($_POST['update'])){
    $masv = $_POST['masv'];
    $hoten = $_POST['hoten'];
    $lop = $_POST['lop'];
    $diem = $_POST['diem'];

    // Prepared statement để update
    $stmt = $conn->prepare("UPDATE sinhvien SET masv=?, hoten=?, lop=?, diem=? WHERE id=?");
    $stmt->bind_param("sssdi", $masv, $hoten, $lop, $diem, $id);

    if($stmt->execute()){
        $stmt->close();
        header("Location: index.php"); // Quay về danh sách
        exit;
    } else {
        $error = "Lỗi: Không thể cập nhật!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa sinh viên - Văn Lang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* ===== BODY & BACKGROUND ===== */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('asset/anh.jpg'); /* đổi tên ảnh của bạn */
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            position: relative;
        }
        body::before {
            content: "";
            position: fixed;
            top:0; left:0;
            width:100%; height:100%;
            background: rgba(255,255,255,0.3);
            z-index: -1;
        }

        /* ===== HEADER ===== */
        .header-vlu {
            background-color: #C8102E;
            color: white;
            padding: 20px;
            text-align: center;
            font-weight: bold;
            font-size: 22px;
            border-radius: 0 0 12px 12px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
        }

        /* ===== MENU ===== */
        .menu-vlu {
            background-color: white;
            border-bottom: 2px solid #ddd;
            text-align: center;
        }
        .menu-vlu a {
            color: #C8102E;
            text-decoration: none;
            font-weight: bold;
            padding: 12px 20px;
            display: inline-block;
            transition: 0.3s;
        }
        .menu-vlu a:hover {
            background-color: #ffe5e8;
            border-radius: 5px;
        }

        /* ===== CARD ===== */
        .card-vlu {
            background: rgba(255,255,255,0.75);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 4px 15px rgba(0,0,0,0.15);
            margin-top: 30px;
        }

        /* ===== INPUT ===== */
        input.form-control {
            margin-bottom: 15px;
        }

        /* ===== BUTTONS ===== */
        .btn-vlu-primary {
            background-color: #C8102E;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 8px 15px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }
        .btn-vlu-primary:hover {
            background-color: #a60b24;
        }
        .btn-secondary {
            padding: 8px 15px;
            background: #ccc;
            color: #000;
            text-decoration: none;
            border-radius: 6px;
            transition: 0.3s;
        }
        .btn-secondary:hover {
            background: #bbb;
        }
    </style>
</head>
<body>

<!-- Header -->
<div class="header-vlu">
    ✏️ Sửa thông tin sinh viên - Đại học Văn Lang
</div>

<!-- Menu -->
<div class="menu-vlu">
    <a href="index.php">Trang chủ</a>
    <a href="add.php">Thêm sinh viên</a>
    <a href="sort.php">Sắp xếp</a>
    <a href="stats.php">Thống kê</a>
    <a href="logout.php">Đăng xuất</a>
</div>

<!-- Nội dung -->
<div class="container">
    <div class="card-vlu mt-4">

        <?php if(isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

        <form method="POST">
            <label>Mã Sinh viên</label>
            <input type="text" name="masv" class="form-control" value="<?= htmlspecialchars($row['masv']) ?>" required>

            <label>Họ Tên</label>
            <input type="text" name="hoten" class="form-control" value="<?= htmlspecialchars($row['hoten']) ?>" required>

            <label>Lớp</label>
            <input type="text" name="lop" class="form-control" value="<?= htmlspecialchars($row['lop']) ?>">

            <label>Điểm</label>
            <input type="number" step="0.1" name="diem" class="form-control" value="<?= htmlspecialchars($row['diem']) ?>">

            <button type="submit" name="update" class="btn btn-vlu-primary">Cập nhật</button>
            <a href="index.php" class="btn btn-secondary">← Quay lại</a>
        </form>

    </div>
</div>

</body>
</html>
